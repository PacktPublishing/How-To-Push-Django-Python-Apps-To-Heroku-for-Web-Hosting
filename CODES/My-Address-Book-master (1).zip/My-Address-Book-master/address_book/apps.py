from django.apps import AppConfig


class AddressBookConfig(AppConfig):
    name = 'address_book'
